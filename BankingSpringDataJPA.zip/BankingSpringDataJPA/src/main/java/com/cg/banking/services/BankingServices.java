package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.*;
import com.cg.banking.exceptions.*;
public interface BankingServices {
	int acceptCustomerDetails(String firstName,String lastName,String customerEmailId,String panCard,String localAddressCity,
			String localAddressState,int localAddressPinCode,String homeAddressCity,
			String homeAddressState,int homeAddressPinCode)throws BankingServicesDownException;
	long openAccount(int customerId,String accountType,float initBalance)
			throws InvalidAmountException,
			CustomerNotFoundException,
			InvalidAccountTypeException,
			BankingServicesDownException;
	float depositAmount(int customerId,long accountNo,float amount)
			throws CustomerNotFoundException,
			AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InvalidAmountException;
	float withdrawAmount(int customerId,long accountNo,float amount,int pinNumber)
			throws InsufficientAmountException,CustomerNotFoundException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException, InvalidAmountException;
	boolean fundTransfer(int customerIdTo,long accountNoTo,int customerIdFrom,long accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,
			CustomerNotFoundException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, InvalidAmountException;
	Customer getCustomerDetails(int customerId)
			throws CustomerNotFoundException,BankingServicesDownException;
	Account getAccountDetails(int customerId,long accountNo)
			throws 
			CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException;
	public int generateNewPin(int customerId,long accountNo)
			throws
			CustomerNotFoundException,AccountNotFoundException ,
			BankingServicesDownException;
	public boolean changeAccountPin(int customerId,long accountNo,int oldPinNumber,int newPinNumber)
			throws CustomerNotFoundException,
			AccountNotFoundException,
			InvalidPinNumberException,BankingServicesDownException  ;
	List<Customer> getAllCustomerDetails()throws BankingServicesDownException;
	List<Account> getcustomerAllAccountDetails(int customerId)throws BankingServicesDownException,CustomerNotFoundException;
	List<Transaction> getAccountAllTransaction(int customerId,long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException;
	boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException,
			CustomerNotFoundException,
			AccountNotFoundException;
	public boolean removeCustomer(int customerId)throws BankingServicesDownException,CustomerNotFoundException;
}