package com.cg.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.banking.beans.*;
public interface BankingDAOServices1 extends JpaRepository<Account, Long>{
	
}