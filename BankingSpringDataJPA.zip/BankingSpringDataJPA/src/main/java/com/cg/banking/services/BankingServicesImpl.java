package com.cg.banking.services;
import java.lang.annotation.Target;
import java.util.List;
import javax.naming.spi.InitialContextFactoryBuilder;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.*;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServices1;
import com.cg.banking.daoservices.BankingDAOServices2;
import com.cg.banking.exceptions.*;
import com.cg.banking.utility.BankingUtility;
@Component(value="bankingServices")
public class BankingServicesImpl implements BankingServices{
	@Autowired
	private BankingDAOServices bankingDAOServices;
	@Autowired
	private BankingDAOServices1 bankingDAOServices1;
	@Autowired
	private BankingDAOServices2 bankingDAOServices2;
	@Transactional
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		Customer customer = bankingDAOServices.save(new Customer(firstName, lastName, emailId, panCard, new Address(homeAddressPinCode, homeAddressCity, homeAddressState),new Address(localAddressPinCode, localAddressCity, localAddressState)));
		return customer.getCustomerId();
	}
	@Transactional
	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")){
			if(initBalance<=0)
			throw new InvalidAmountException("The given amount for initial balance is inavlid. Please input vaild initial balance");
			Customer customer = bankingDAOServices.findOne(customerId);
			Account account = bankingDAOServices1.save(new Account(accountType, initBalance));
			account.setCustomer(customer);
			return account.getAccountNo();
		}
		throw new InvalidAccountTypeException("Account Tpye must be Valid");
	}
	@Transactional
	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices1.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		if(amount<=0)
			throw new InvalidAmountException("Enter Valid Amount to Deposit");
		else{
			Account account=bankingDAOServices1.findOne(accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
		    Transaction transaction = bankingDAOServices2.save(new Transaction(amount, "Deposit"));
		    transaction.setAccount(account);
			bankingDAOServices2.saveAndFlush(transaction);
		return  bankingDAOServices1.findOne(accountNo).getAccountBalance();
		}
		
	}
	@Transactional
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(amount<=0)
			throw new InvalidAmountException("Enter correct amount");
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices1.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		if(bankingDAOServices1.findOne(accountNo).getPinNumber()==pinNumber){
			if(bankingDAOServices1.findOne(accountNo).getAccountBalance()-amount>=0){
				Account account = bankingDAOServices1.findOne(accountNo);
				account.setAccountBalance(account.getAccountBalance()-amount);
				Transaction transaction = bankingDAOServices2.save(new Transaction(amount, "WithDraw"));
				transaction.setAccount(account);
				bankingDAOServices1.saveAndFlush(account);
				bankingDAOServices2.saveAndFlush(transaction);
			}
			else
				throw new InsufficientAmountException("Given ammount is not sufficient to withdraw");
		}
		else
			throw new InvalidPinNumberException("Enter Valid Pin Number");
		return bankingDAOServices1.findOne(accountNo).getAccountBalance();	

	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		if(bankingDAOServices1.findOne(accountNoFrom).getPinNumber()==pinNumber){
			withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
			depositAmount(customerIdTo, accountNoTo, transferAmount);
		}
		else
			throw new InvalidPinNumberException("Enter Valid Pin Number");
		return true;
	}
	@Transactional
	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		Customer customer = bankingDAOServices.findOne(customerId);
		return customer;
	}
	@Transactional
	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.findOne(customerId)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		Account account = bankingDAOServices1.findOne(accountNo);
		return account;
	}
	
	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices1.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		    Account account = bankingDAOServices1.findOne(accountNo);
		    account.setPinNumber(BankingUtility.rand.nextInt(9999));
		    bankingDAOServices1.saveAndFlush(account);
		    return account.getPinNumber();
		    
	}
	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		else if(bankingDAOServices1.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		else if(oldPinNumber==bankingDAOServices1.findOne(accountNo).getPinNumber()){
			Account account = bankingDAOServices1.findOne(accountNo);
			account.setPinNumber(newPinNumber);
			bankingDAOServices1.saveAndFlush(account);
			return true;
		}
		else
			throw new InvalidPinNumberException("The given pin is not valid");
	}
	@Transactional
	@Override
	public  List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return bankingDAOServices.findAll();
	}
	@Transactional
	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		return bankingDAOServices1.findAll();
	}
	@Transactional
	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.findOne(customerId)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		return bankingDAOServices2.findAll();
	}
	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices1.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		bankingDAOServices1.delete(accountNo);
		return true;
	}
	@Override
	public boolean removeCustomer(int customerId) throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingDAOServices.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
				bankingDAOServices.delete(customerId);
				return true;
	}
}
